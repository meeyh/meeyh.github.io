# arch

> Display the name of the system architecture.
> See also `uname`.
> More information: <https://www.gnu.org/software/coreutils/arch>.

- Display the system's architecture:

`arch`
