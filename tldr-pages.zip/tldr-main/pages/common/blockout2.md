# blockout2

> Tetris like game in 3D.
> More information: <http://www.blockout.net/blockout2/>.

- Start a new game:

`blockout2`

- Navigate the current piece on a 2D plane:

`{{Up|Down|Left|Right}} arrow key`

- Rotate the piece on its axis:

`{{Q|W|E|A|S|D}}`

- Hard drop the current piece:

`Spacebar`

- Pause/unpause the game:

`p`
