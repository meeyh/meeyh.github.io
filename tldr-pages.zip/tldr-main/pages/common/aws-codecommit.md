# aws codecommit

> AWS CodeCommit is a managed source control service that hosts private Git repositories.
> More information: <https://docs.aws.amazon.com/cli/latest/reference/codecommit/>.

- Display help for a specific command:

`aws codecommit {{command}} help`

- Display help:

`aws codecommit help`
