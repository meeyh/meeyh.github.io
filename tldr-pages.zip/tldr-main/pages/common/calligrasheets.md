# calligrasheets

> Calligra's spreadsheet application.
> See also: `calligraflow`, `calligrastage`, `calligrawords`.
> More information: <https://manned.org/calligrasheets>.

- Launch the spreadsheet application:

`calligrasheets`

- Open a specific spreadsheet:

`calligrasheets {{path/to/spreadsheet}}`

- Display help or version:

`calligrasheets --{{help|version}}`
