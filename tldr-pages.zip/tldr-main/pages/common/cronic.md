# cronic

> Bash script for wrapping cron jobs to prevent excess email sending.
> More information: <https://habilis.net/cronic/>.

- Call a command and display its output if it returns a non-zero exit code:

`cronic {{command}}`
