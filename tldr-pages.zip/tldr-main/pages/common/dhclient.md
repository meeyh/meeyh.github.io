# dhclient

> DHCP client.
> More information: <https://manned.org/dhclient>.

- Get an IP address for the `eth0` interface:

`sudo dhclient {{eth0}}`

- Release an IP address for the `eth0` interface:

`sudo dhclient -r {{eth0}}`
