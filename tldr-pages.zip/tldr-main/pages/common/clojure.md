# clojure

> This command is an alias of `clj`.

- View documentation for the original command:

`tldr clj`
