# aria2

> This command is an alias of `aria2c`.

- View documentation for the updated command:

`tldr aria2c`
